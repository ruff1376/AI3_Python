MILES = 0.6213
POUND = 0.0022

# 킬로미터를 마일로 변환하는 함수
def kilometer_to_miles( kilometer ):
    return kilometer * MILES


# 그램을 파운드로 변환하는 함수
def gram_to_pound( gram ):
    return gram * POUND